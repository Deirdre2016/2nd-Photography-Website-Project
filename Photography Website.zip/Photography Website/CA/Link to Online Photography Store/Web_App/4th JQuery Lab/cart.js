var page_load = document.getElementById("Cart");
page_load.addEventListener("load",loadCart());
function loadCart(){
	if(!sessionStorage.getItem("qty1")&&!sessionStorage.getItem("qty3")){
		document.getElementById("warn").innerHTML="No items selected for order. Return to home page - Click the back button<br><br>";
		sessionStorage.clear();
		page_load.style.visibility="hidden";
	}else{
		document.getElementById("warn").innerHTML="";
		page_load.style.visibility="visible";	
		populateTable();
	}
}

function populateTable(){
	var cost1 = 0;
	var cost2 = 0;	
	var cost3 = 0;
	var cost4 = 0;
	var cost5 = 0;
	var cost6 = 0;
	if(!sessionStorage.getItem("qty1")){
		document.getElementById("product1").innerHTML = "(Ref 101)- Sunset over Claddagh, Galway";
		document.getElementById("price1").innerHTML = "40.00";
		document.getElementById("qty1").innerHTML = "0";
		document.getElementById("cost1").innerHTML = "0";
		document.getElementById("cost1").innerHTML = "0";
		cost1=0;		
	}else{
		document.getElementById("product1").innerHTML = sessionStorage.getItem("product1");
		document.getElementById("price1").innerHTML = sessionStorage.getItem("price1");
		document.getElementById("qty1").innerHTML = sessionStorage.getItem("qty1");
		cost1=parseFloat(sessionStorage.getItem("qty1")) * sessionStorage.getItem("price1");
		document.getElementById("cost1").innerHTML = "€"+cost1.toFixed(2);			
	}
	if(!sessionStorage.getItem("qty2")){
		document.getElementById("product2").innerHTML = "(Ref 102)- View of long walk, Claddagh, Galway";
		document.getElementById("price2").innerHTML = "50.00";
		document.getElementById("qty2").innerHTML = "0";
		document.getElementById("cost2").innerHTML = "0";
		cost2=0;	
	}else{
		document.getElementById("product2").innerHTML = sessionStorage.getItem("product2");
		document.getElementById("price2").innerHTML = sessionStorage.getItem("price2");
		document.getElementById("qty2").innerHTML = sessionStorage.getItem("qty2");
		cost2=parseFloat(sessionStorage.getItem("qty2")) * sessionStorage.getItem("price2");
		document.getElementById("cost2").innerHTML = "€"+cost2.toFixed(2);			
	}
	if(!sessionStorage.getItem("qty3")){
		document.getElementById("product3").innerHTML = "(Ref 103)- Night sky over Claddagh, Galway";
		document.getElementById("price3").innerHTML = "60.00";
		document.getElementById("qty3").innerHTML = "0";
		document.getElementById("cost3").innerHTML = "0";
		cost3=0;	
	}else{
		document.getElementById("product3").innerHTML = sessionStorage.getItem("product3");
		document.getElementById("price3").innerHTML = sessionStorage.getItem("price3");
		document.getElementById("qty3").innerHTML = sessionStorage.getItem("qty3");
		cost3=parseFloat(sessionStorage.getItem("qty3")) * sessionStorage.getItem("price3");
		document.getElementById("cost3").innerHTML = "€"+cost3.toFixed(2);			
	}
	if(!sessionStorage.getItem("qty4")){
		document.getElementById("product4").innerHTML = "(Ref 104)- Sunshine through Church Stained glass window";
		document.getElementById("price4").innerHTML = "70.00";
		document.getElementById("qty4").innerHTML = "0";
		document.getElementById("cost4").innerHTML = "0";
		cost4=0;	
	}else{
		document.getElementById("product4").innerHTML = sessionStorage.getItem("product4");
		document.getElementById("price4").innerHTML = sessionStorage.getItem("price4");
		document.getElementById("qty4").innerHTML = sessionStorage.getItem("qty4");
		cost4=parseFloat(sessionStorage.getItem("qty4")) * sessionStorage.getItem("price4");
		document.getElementById("cost4").innerHTML = "€"+cost4.toFixed(2);			
	}
	if(!sessionStorage.getItem("qty5")){
		document.getElementById("product5").innerHTML = "(Ref 105)- Art Exhibition Photo";
		document.getElementById("price5").innerHTML = "80.00";
		document.getElementById("qty5").innerHTML = "0";
		document.getElementById("cost5").innerHTML = "0";
		cost5=0;	
	}else{
		document.getElementById("product5").innerHTML = sessionStorage.getItem("product5");
		document.getElementById("price5").innerHTML = sessionStorage.getItem("price5");
		document.getElementById("qty5").innerHTML = sessionStorage.getItem("qty5");
		cost5=parseFloat(sessionStorage.getItem("qty5")) * sessionStorage.getItem("price5");
		document.getElementById("cost5").innerHTML = "€"+cost5.toFixed(2);			
	}
	if(!sessionStorage.getItem("qty6")){
		document.getElementById("product6").innerHTML = "(Ref 106)- Art Exhibition Photo1";
		document.getElementById("price6").innerHTML = "90.00";
		document.getElementById("qty6").innerHTML = "0";
		document.getElementById("cost6").innerHTML = "0";
		cost6=0;	
	}else{
		document.getElementById("product6").innerHTML = sessionStorage.getItem("product6");
		document.getElementById("price6").innerHTML = sessionStorage.getItem("price6");
		document.getElementById("qty6").innerHTML = sessionStorage.getItem("qty6");
		cost6=parseFloat(sessionStorage.getItem("qty6")) * sessionStorage.getItem("price6");
		document.getElementById("cost6").innerHTML = "€"+cost6.toFixed(2);			
	}
	document.getElementById("total").innerHTML="€"+(cost1+cost2+cost3+cost4+cost5+cost6).toFixed(6);
	sessionStorage.setItem("total",(cost1+cost2+cost3+cost4+cost5+cost6).toFixed(2)); 
}

var input1 =document.getElementById('b1');
input1.addEventListener("click", function(){removeFromCart1(event);});
		
function removeFromCart1(event){
	sessionStorage.removeItem("product1");
	sessionStorage.removeItem("price1");
	sessionStorage.removeItem("qty1");
	window.location.reload();
}

var input2 =document.getElementById('b2');
input2.addEventListener("click", function(){removeFromCart2(event);});

function removeFromCart2(event){
	sessionStorage.removeItem("product2");
	sessionStorage.removeItem("price2");
	sessionStorage.removeItem("qty2");
	window.location.reload();
}

var input3 =document.getElementById('b3');
input3.addEventListener("click", function(){removeFromCart3(event);});

function removeFromCart3(event){
	sessionStorage.removeItem("product3");
	sessionStorage.removeItem("price3");
	sessionStorage.removeItem("qty3");
	window.location.reload();
}
var input4 =document.getElementById('b4');
input4.addEventListener("click", function(){removeFromCart4(event);});

function removeFromCart4(event){
	sessionStorage.removeItem("product4");
	sessionStorage.removeItem("price4");
	sessionStorage.removeItem("qty4");
	window.location.reload();
}
var input5 =document.getElementById('b5');
input5.addEventListener("click", function(){removeFromCart5(event);});

function removeFromCart5(event){
	sessionStorage.removeItem("product5");
	sessionStorage.removeItem("price5");
	sessionStorage.removeItem("qty5");
	window.location.reload();
}
var input6 =document.getElementById('b6');
input6.addEventListener("click", function(){removeFromCart6(event);});

function removeFromCart6(event){
	sessionStorage.removeItem("product6");
	sessionStorage.removeItem("price6");
	sessionStorage.removeItem("qty6");
	window.location.reload();
}

document.getElementById("back").addEventListener("click", goBack);
function goBack(){
	window.location.href="index.html";
}

document.getElementById("remove").addEventListener("click", remove);
function remove(){
	window.location.href="cart.html";
}

/* products */
function product(){
	this.name="";
	this.price=0.00;
}

var product1 = new product();
product1.name="(Ref 101)- Sunset over Claddagh, Galway";
product1.price=40.00;

var product2 = new product();
product2.name="(Ref 102)- View of long walk, Claddagh";
product2.price=50.00;

var product3 = new product();
product3.name="(Ref 103)- Night sky over Claddagh, Galway";
product3.price=60.00;

var product4 = new product();
product4.name="(Ref 104)- Sunshine through Church Stained glass window";
product4.price=70.00;

var product5 = new product();
product5.name="(Ref 105)- Art Exhibition Photo";
product5.price=80.00;

var product6 = new product();
product6.name="(Ref 106)- Art Exhibition Photo1";
product6.price=90.00;

document.getElementById("name1").innerHTML=product1.name;
document.getElementById("name2").innerHTML=product2.name;
document.getElementById("name3").innerHTML=product3.name;
document.getElementById("name4").innerHTML=product4.name;
document.getElementById("name5").innerHTML=product5.name;
document.getElementById("name6").innerHTML=product6.name;



document.getElementById("price1").innerHTML=product1.price.toFixed(2); 
document.getElementById("price2").innerHTML=product2.price.toFixed(2);
document.getElementById("price3").innerHTML=product3.price.toFixed(2);
document.getElementById("price4").innerHTML=product4.price.toFixed(2);
document.getElementById("price5").innerHTML=product5.price.toFixed(2);
document.getElementById("price6").innerHTML=product6.price.toFixed(2);



document.getElementById("i1").value=sessionStorage.getItem("qty1")||0;
document.getElementById("i2").value=sessionStorage.getItem("qty2")||0;
document.getElementById("i3").value=sessionStorage.getItem("qty3")||0;
document.getElementById("i4").value=sessionStorage.getItem("qty4")||0;
document.getElementById("i5").value=sessionStorage.getItem("qty5")||0;
document.getElementById("i6").value=sessionStorage.getItem("qty6")||0;
   
   
   
document.getElementById("b1").addEventListener("click", addToCart1);
function addToCart1(){
	var qty = document.getElementById("i1").value;
	if(isNaN(qty)){
		alert("Must provide a number only for quantity");
		return false;
	}
	sessionStorage.setItem("product1","(Ref 101)- Sunset over Claddagh, Galway");
	sessionStorage.setItem("price1",40.00);
	sessionStorage.setItem("qty1",qty);
	if(qty==1){
		var pair="pair";
	}else{
		var pair="pairs"
	}
	alert(qty+" of (Ref 101)- Sunset over Claddagh, Galway added to cart\n Total cost is: €"+(40*qty));
}

document.getElementById("b2").addEventListener("click", addToCart2);
function addToCart2(){
	var qty = document.getElementById("i2").value;
	if(isNaN(qty)){
		alert("Must provide a number only for quantity");
		return false;
	}
	sessionStorage.setItem("product2","(Ref 102)- View of long walk, Claddagh");
	sessionStorage.setItem("price2",50.00);
	sessionStorage.setItem("qty2",qty);
	if(qty==1){
		var pair="pair";
	}else{
		var pair="pairs"
	}
	alert(qty+" of (Ref 102)- View of long walk, Claddagh added to cart\n Total cost is: €"+(50*qty));
}

document.getElementById("b3").addEventListener("click", addToCart3);
function addToCart3(){
	var qty = document.getElementById("i3").value;
	if(isNaN(qty)){
		alert("Must provide a number only for quantity");
		return false;
	}
	sessionStorage.setItem("product3","(Ref 103)- Night sky over Claddagh, Galway");
	sessionStorage.setItem("price3",60.00);
	sessionStorage.setItem("qty3",qty);
	if(qty==1){
		var pair="pair";
	}else{
		var pair="pairs"
	}
	alert(qty+" of (Ref 103)- Night sky over Claddagh, Galway added to cart\n Total cost is: €"+(60*qty));
}

document.getElementById("b4").addEventListener("click", addToCart4);
function addToCart4(){
	var qty = document.getElementById("i4").value;
	if(isNaN(qty)){
		alert("Must provide a number only for quantity");
		return false;
	}
	sessionStorage.setItem("product4","(Ref 104)- Sunshine through Church Stained glass window");
	sessionStorage.setItem("price4",70.00);
	sessionStorage.setItem("qty4",qty);
	if(qty==1){
		var pair="pair";
	}else{
		var pair="pairs"
	}
	alert(qty+" of (Ref 104)- Sunshine through Church Stained glass window added to cart\n Total cost is: €"+(70*qty));
}

document.getElementById("b5").addEventListener("click", addToCart5);
function addToCart5(){
	var qty = document.getElementById("i5").value;
	if(isNaN(qty)){
		alert("Must provide a number only for quantity");
		return false;
	}
	sessionStorage.setItem("product5","(Ref 106)- Art Exhibition Photo1");
	sessionStorage.setItem("price5",80.00);
	sessionStorage.setItem("qty5",qty);
	if(qty==1){
		var pair="pair";
	}else{
		var pair="pairs"
	}
	alert(qty+" of (Ref 106)- Art Exhibition Photo1 added to cart\n Total cost is: €"+(80*qty));
}

document.getElementById("b6").addEventListener("click", addToCart6);
function addToCart6(){
	var qty = document.getElementById("i6").value;
	if(isNaN(qty)){
		alert("Must provide a number only for quantity");
		return false;
	}
	sessionStorage.setItem("product6","(Ref 106)- Art Exhibition Photo1");
	sessionStorage.setItem("price6",90.00);
	sessionStorage.setItem("qty6",qty);
	if(qty==1){
		var pair="pair";
	}else{
		var pair="pairs"
	}
	alert(qty+" of (Ref 106)- Art Exhibition Photo1 added to cart\n Total cost is: €"+(90*qty));
}